"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { Play, Pause, RotateCcw, Settings2, Zap, Radar, RefreshCw } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { scoreParamsFast } from "../../lib/fastsim";
import type { FastScoreResult } from "../../lib/fastsim";

/**
 * Airpark Live Dashboard (single-file page/component)
 * --------------------------------------------------
 * - Drop this file into a Next.js app router project as: app/airpark/page.tsx
 * - Ensure Tailwind is set up. Install deps: `npm i recharts framer-motion lucide-react`
 * - Start: `npm run dev` then open /airpark
 *
 * Notes:
 * - This is a browser-side simulation port inspired by your Python A–F logic.
 * - It’s designed for clarity + tweakability, not perfect parity.
 * - Midair preempts wall; direction via shadow test; g scales with closure/TCA.
 * - Guardrail: early-exit when opening sustained (simplified). Retrigger if still closing.
 * - OOB return-to-box aligns toward nearest point on the box and releases when inside by a margin.
 */

/*********************************
 * Tunables & Defaults
 *********************************/
const WORLD_W = 900; // meters (display mapped to pixels 1:1 in canvas, responsive scaled)
const WORLD_H = 600;
const TICK_HZ = 30; // sim ticks per second
const MAX_AIRCRAFT = 8;

// Midair knobs (A–F references)
const DEFAULTS = {
  MID_TTC_THRESHOLD: 3.0, // A/D
  MID_SEP_TRIGGER: 60.0, // A/D
  WALL_TTC_THRESHOLD: 2.5,
  WALL_PADDING: 10.0,
  K_GAIN: 0.2, // D
  G_MIN: 2.0, // D
  G_MAX: 4.5, // D
  HORIZON_S: 3.0, // B
  H_DT: 0.05, // B
  OPEN_SAFE_SEP: 90.0, // E
  OPEN_HOLD_S: 0.5, // E
  OOB_RETURN_AFTER: 1.5,
  OOB_RETURN_G: 3.0,
  OOB_RELEASE_MARGIN: 5.0,
};

/*********************************
 * Math helpers
 *********************************/
const clamp = (x: number, lo: number, hi: number) => (x < lo ? lo : x > hi ? hi : x);
const len = (v: Vec2) => Math.hypot(v.x, v.y);
const dot = (a: Vec2, b: Vec2) => a.x * b.x + a.y * b.y;
const sub = (a: Vec2, b: Vec2): Vec2 => ({ x: a.x - b.x, y: a.y - b.y });
const add = (a: Vec2, b: Vec2): Vec2 => ({ x: a.x + b.x, y: a.y + b.y });
const mul = (a: Vec2, s: number): Vec2 => ({ x: a.x * s, y: a.y * s });
const norm = (v: Vec2): Vec2 => {
  const L = len(v) || 1e-9;
  return { x: v.x / L, y: v.y / L };
};
const rot = (v: Vec2, ang: number): Vec2 => {
  const c = Math.cos(ang), s = Math.sin(ang);
  return { x: c * v.x - s * v.y, y: s * v.x + c * v.y };
};

/*********************************
 * Types
 *********************************/
interface Vec2 { x: number; y: number }

type ControllerName = "NormalMotion" | "ArcTurn" | "ReturnToBox";

type Controller =
  | { name: "NormalMotion" }
  | {
      name: "ArcTurn";
      direction: 1 | -1; // +1 left CCW, -1 right CW
      gLimit: number;
      totalAngle: number; // radians
      advanced: number; // radians accumulated
      source: "midair" | "wall";
      exitFraction: number;
      triggerId?: string;
    }
  | {
      name: "ReturnToBox";
      gLimit: number;
      desired: Vec2; // desired unit vector each tick
    };

interface Aircraft {
  id: string;
  color: string;
  pos: Vec2;
  vel: Vec2;
  speed: number;
  targetSpeed: number;
  accel: number;
  decel: number;
  overrides: { midair?: Controller; wall?: Controller };
  motion: Controller; // NormalMotion
  lastRespawn: number;
}

interface Params {
  MID_TTC_THRESHOLD: number;
  MID_SEP_TRIGGER: number;
  WALL_TTC_THRESHOLD: number;
  WALL_PADDING: number;
  K_GAIN: number;
  G_MIN: number;
  G_MAX: number;
  HORIZON_S: number;
  H_DT: number;
  OPEN_SAFE_SEP: number;
  OPEN_HOLD_S: number;
  OOB_RETURN_AFTER: number;
  OOB_RETURN_G: number;
  OOB_RELEASE_MARGIN: number;
  enableMidair: boolean;
  enableWall: boolean;
  enableGuardrail: boolean; // tighten/flip disabled in this lightweight port; we keep early-exit + retrigger
  enableOOBReturn: boolean;
}

interface TriggerLogRow {
  t: number;
  aid: string;
  triggerId: string;
  source: string;
  note: string;
}

/*********************************
 * Arena + Simulation
 *********************************/
function randomColor(i: number) {
  const palette = ["#ffcc66", "#76c7ff", "#a2f38f", "#ff8fa3", "#d0b3ff", "#ffd480", "#9be7ff", "#b3ffcc"]; // pleasant
  return palette[i % palette.length];
}

let globalIdCounter = 0;
function newAircraft(i: number): Aircraft {
  const id = `A${++globalIdCounter}`;
  const pos = { x: Math.random() * WORLD_W, y: Math.random() * WORLD_H };
  const heading = Math.random() * Math.PI * 2;
  const speed = 53.6;
  return {
    id,
    color: randomColor(i),
    pos,
    vel: { x: Math.cos(heading) * speed, y: Math.sin(heading) * speed },
    speed,
    targetSpeed: speed,
    accel: 10,
    decel: 10,
    overrides: {},
    motion: { name: "NormalMotion" },
    lastRespawn: -1e9,
  };
}

function isOutOfBounds(p: Vec2) {
  return p.x < 0 || p.x > WORLD_W || p.y < 0 || p.y > WORLD_H;
}
function isInsideMargin(p: Vec2, m: number) {
  return p.x >= m && p.x <= WORLD_W - m && p.y >= m && p.y <= WORLD_H - m;
}

function distance(a: Vec2, b: Vec2) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function getPairs(ids: string[]) {
  const pairs: [string, string][] = [];
  for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) pairs.push([ids[i], ids[j]]);
  return pairs;
}

// Wall TTC (time-to-collision with bounds) under constant heading
function computeWallTTC(a: Aircraft): { ttc: number | null; wall: "left" | "right" | "top" | "bottom" | null } {
  const x = a.pos.x, y = a.pos.y;
  const vhat = norm(a.vel);
  const s = a.speed;
  const cands: { wall: "left" | "right" | "top" | "bottom"; t: number }[] = [];
  if (vhat.x < -1e-9) cands.push({ wall: "left", t: -x / (vhat.x * s) });
  if (vhat.x > +1e-9) cands.push({ wall: "right", t: (WORLD_W - x) / (vhat.x * s) });
  if (vhat.y < -1e-9) cands.push({ wall: "top", t: -y / (vhat.y * s) });
  if (vhat.y > +1e-9) cands.push({ wall: "bottom", t: (WORLD_H - y) / (vhat.y * s) });
  const pos = cands.filter((c) => c.t >= 0);
  if (pos.length === 0) return { ttc: null, wall: null };
  const best = pos.reduce((m, c) => (c.t < m.t ? c : m));
  return { ttc: best.t, wall: best.wall };
}

// Midair closest approach
function computeMidairTCA(a: Aircraft, b: Aircraft) {
  const r = sub(a.pos, b.pos);
  const v = sub(a.vel, b.vel);
  const v2 = dot(v, v);
  if (v2 < 1e-12) return { tStar: null, dMin: null };
  const tStar = -dot(r, v) / v2;
  if (tStar < 0) return { tStar: null, dMin: null };
  const dMin = len(add(r, mul(v, tStar)));
  return { tStar, dMin };
}

function shouldTriggerMidair(a: Aircraft, b: Aircraft, P: Params) {
  const { tStar, dMin } = computeMidairTCA(a, b);
  if (tStar === null || dMin === null) return { trigger: false, tStar, dMin };
  return { trigger: tStar <= P.MID_TTC_THRESHOLD && dMin <= P.MID_SEP_TRIGGER, tStar, dMin };
}

// Shadow test: simulate left/right ArcTurn over horizon, pick higher min separation
function pickDirectionShadow(a: Aircraft, intr: Aircraft, gLimit: number, P: Params) {
  const test = (dir: 1 | -1) => {
    let pos = { ...a.pos };
    let vel = { ...a.vel };
    let minSep = Infinity;
    const speed = a.speed;
    const omega = (gLimit * 9.81) / (speed || 1e-9);
    const steps = Math.ceil(P.HORIZON_S / P.H_DT);
    for (let k = 0; k < steps; k++) {
      // rotate vel by small step
      const dv = clamp(omega * P.H_DT, -Math.PI, Math.PI) * dir;
      vel = rot(norm(vel), dv);
      vel = mul(vel, speed);
      pos = add(pos, mul(vel, P.H_DT));
      const intrPos = add(intr.pos, mul(intr.vel, (k + 1) * P.H_DT));
      const d = distance(pos, intrPos);
      if (d < minSep) minSep = d;
    }
    return minSep;
  };
  const left = test(+1);
  const right = test(-1);
  return left >= right ? { dir: 1 as 1, minSep: left } : { dir: -1 as -1, minSep: right };
}

function nearestIntruder(a: Aircraft, all: Aircraft[]) {
  let best: { b: Aircraft; d: number } | null = null;
  for (const b of all) {
    if (b.id === a.id) continue;
    const d = distance(a.pos, b.pos);
    if (!best || d < best.d) best = { b, d };
  }
  return best?.b ?? null;
}

function desiredInboundUnit(a: Aircraft): Vec2 {
  // vector to nearest point on box (clamped), works near corners
  const tx = clamp(a.pos.x, 0, WORLD_W);
  const ty = clamp(a.pos.y, 0, WORLD_H);
  const d = { x: tx - a.pos.x, y: ty - a.pos.y };
  const L = Math.hypot(d.x, d.y) || 1e-9;
  return { x: d.x / L, y: d.y / L };
}

/*********************************
 * Simulation step
 *********************************/
function updateAircraft(a: Aircraft, dt: number) {
  // speed convergence
  const dv = a.targetSpeed - a.speed;
  const accel = clamp(dv / (dt || 1e-9), -a.decel, a.accel);
  a.speed += accel * dt;
  // active controller
  const active = a.overrides.midair || a.overrides.wall || a.motion;
  if (active.name === "NormalMotion") {
    // keep heading, nothing special
  } else if (active.name === "ArcTurn") {
    const vhat = norm(a.vel);
    const omega = (active.gLimit * 9.81) / (a.speed || 1e-9);
    const dtheta = clamp(omega * dt, -Math.PI, Math.PI) * active.direction;
    a.vel = mul(rot(vhat, dtheta), a.speed);
    active.advanced += Math.abs(dtheta);
    const frac = active.advanced / (active.totalAngle || Math.PI);
    if (frac >= active.exitFraction) {
      // mark done -> cleared in cleanup
      (active as any).done = true;
    }
  } else if (active.name === "ReturnToBox") {
    const vhat = norm(a.vel);
    const omega = (active.gLimit * 9.81) / (a.speed || 1e-9);
    // signed angle between vhat and desired
    const cross = vhat.x * active.desired.y - vhat.y * active.desired.x;
    const dotp = clamp(vhat.x * active.desired.x + vhat.y * active.desired.y, -1, 1);
    const ang = Math.atan2(cross, dotp);
    const dtheta = clamp(ang, -omega * dt, omega * dt);
    a.vel = mul(rot(vhat, dtheta), a.speed);
  }

  // integrate position
  a.vel = mul(norm(a.vel), a.speed);
  a.pos = add(a.pos, mul(a.vel, dt));
}

/*********************************
 * Page Component
 *********************************/
export default function AirparkPage() {
  const [aircraft, setAircraft] = useState<Aircraft[]>(() => Array.from({ length: 5 }, (_, i) => newAircraft(i)));
  const [running, setRunning] = useState(true);
  const [time, setTime] = useState(0);
  const [params, setParams] = useState<Params>({
    ...DEFAULTS,
    enableMidair: true,
    enableWall: true,
    enableGuardrail: true,
    enableOOBReturn: true,
  });
  const [logs, setLogs] = useState<TriggerLogRow[]>([]);
  const [history, setHistory] = useState<any[]>([]); // chart rows

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number | null>(null);
  const lastTs = useRef<number | null>(null);

  const pairs = useMemo(() => getPairs(aircraft.map((a) => a.id)), [aircraft]);

  const [fastScore, setFastScore] = useState<FastScoreResult | null>(null);
const [scoring, setScoring] = useState(false);

async function fastScoreNow() {
  try {
    setScoring(true);
    // Run a quick batch (tweak seeds/minutes for speed/accuracy)
    const res = scoreParamsFast(
      {
        WORLD_W, WORLD_H,
        MID_TTC_THRESHOLD: params.MID_TTC_THRESHOLD,
        MID_SEP_TRIGGER: params.MID_SEP_TRIGGER,
        WALL_TTC_THRESHOLD: params.WALL_TTC_THRESHOLD,
        WALL_PADDING: params.WALL_PADDING,
        K_GAIN: params.K_GAIN, G_MIN: params.G_MIN, G_MAX: params.G_MAX,
        HORIZON_S: params.HORIZON_S, H_DT: params.H_DT,
        OPEN_SAFE_SEP: params.OPEN_SAFE_SEP, OPEN_HOLD_S: params.OPEN_HOLD_S,
        OOB_RETURN_AFTER: params.OOB_RETURN_AFTER, OOB_RETURN_G: params.OOB_RETURN_G, OOB_RELEASE_MARGIN: params.OOB_RELEASE_MARGIN,
        enableMidair: params.enableMidair, enableWall: params.enableWall,
        enableGuardrail: params.enableGuardrail, enableOOBReturn: params.enableOOBReturn,
      },
      { seeds: 64, minutes: 2, n: aircraft.length, nearMiss: 30 }
    );
    setFastScore(res);
  } finally {
    setScoring(false);
  }
}

  // Draw arena
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let frame = 0;

    const render = () => {
      const w = canvas.clientWidth, h = canvas.clientHeight;
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w; canvas.height = h;
      }
      ctx.clearRect(0, 0, w, h);

      // scale to world
      const sx = w / WORLD_W, sy = h / WORLD_H;

      // bounds
      ctx.fillStyle = "#0b0e14";
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = "#2a2f3a";
      ctx.lineWidth = 2;
      ctx.strokeRect(0, 0, WORLD_W * sx, WORLD_H * sy);

      // aircraft
      for (const a of aircraft) {
        const x = a.pos.x * sx, y = a.pos.y * sy;
        // shadow (short forward path)
        ctx.strokeStyle = "#88aaff";
        ctx.lineWidth = 1;
        ctx.beginPath();
        let sp = { ...a.pos }, sv = { ...a.vel };
        for (let i = 0; i < 40; i++) {
          sp = add(sp, mul(sv, 0.05));
          const px = sp.x * sx, py = sp.y * sy;
          if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.stroke();
        // body
        ctx.fillStyle = a.color;
        ctx.beginPath();
        ctx.arc(x, y, 5, 0, Math.PI * 2);
        ctx.fill();
      }

      frame++;
      requestAnimationFrame(render);
    };
    const id = requestAnimationFrame(render);
    return () => cancelAnimationFrame(id);
  }, [aircraft]);

  // Simulation loop
  useEffect(() => {
    function step(ts: number) {
      const dt = lastTs.current == null ? 0 : (ts - lastTs.current) / 1000;
      lastTs.current = ts;
      if (running && dt > 0 && dt < 0.25) {
        tick(dt);
      }
      rafRef.current = requestAnimationFrame(step);
    }
    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [running, params, aircraft.length]);

  function logTrigger(aid: string, triggerId: string, source: string, note: string) {
    setLogs((L) => {
      const row: TriggerLogRow = { t: time, aid: aid, triggerId, source, note };
      const next = [row, ...L];
      return next.slice(0, 2000);
    });
  }

  function attemptMidair(a: Aircraft, list: Aircraft[]) {
    if (!params.enableMidair) return false;
    // don't preempt an existing midair
    if (a.overrides.midair && a.overrides.midair.name === "ArcTurn" && a.overrides.midair.source === "midair") return false;

    let best: { b: Aircraft; tca: number; dmin: number } | null = null;
    for (const b of list) {
      if (b.id === a.id) continue;
      const { trigger, tStar, dMin } = shouldTriggerMidair(a, b, params);
      if (trigger && tStar != null && dMin != null) {
        if (!best || tStar < best.tca) best = { b, tca: tStar, dmin: dMin };
      }
    }
    if (!best) return false;

    // g scaling by closure / TCA
    const r = sub(best.b.pos, a.pos);
    const rHat = norm(r);
    const vRel = sub(a.vel, best.b.vel);
    const vClosure = Math.max(0, dot(vRel, rHat));
    const tau = 0.5;
    const gNeeded = clamp(params.K_GAIN * vClosure / Math.max(best.tca, tau), params.G_MIN, params.G_MAX);

    const pick = pickDirectionShadow(a, best.b, gNeeded, params);

    const trig = `M${Math.floor(time * 1000).toString().padStart(6, "0")}`;
    a.overrides.midair = {
      name: "ArcTurn",
      direction: pick.dir,
      gLimit: gNeeded,
      totalAngle: Math.PI,
      advanced: 0,
      source: "midair",
      exitFraction: 0.5,
      triggerId: trig,
    };
    logTrigger(a.id, trig, "midair", `vs ${best.b.id} tca=${best.tca.toFixed(2)} dmin=${best.dmin.toFixed(1)} projMin=${pick.minSep.toFixed(1)}`);
    return true;
  }

  function attemptWall(a: Aircraft) {
    if (!params.enableWall) return false;
    if (a.overrides.wall) return false;
    const { ttc } = computeWallTTC(a);
    if (ttc == null) return false;
    const dist = Math.min(a.pos.x, WORLD_W - a.pos.x, a.pos.y, WORLD_H - a.pos.y);
    if (ttc < params.WALL_TTC_THRESHOLD || dist < params.WALL_PADDING + 5) {
      // choose a turn toward center
      const toCenter = { x: WORLD_W * 0.5 - a.pos.x, y: WORLD_H * 0.5 - a.pos.y };
      const cross = a.vel.x * toCenter.y - a.vel.y * toCenter.x;
      const direction: 1 | -1 = cross >= 0 ? 1 : -1;
      const trig = `W${Math.floor(time * 1000).toString().padStart(6, "0")}`;
      a.overrides.wall = {
        name: "ArcTurn",
        direction,
        gLimit: 3.0,
        totalAngle: Math.PI,
        advanced: 0,
        source: "wall",
        exitFraction: 0.5,
        triggerId: trig,
      };
      logTrigger(a.id, trig, "wall", `ttc~${ttc.toFixed(2)}`);
      return true;
    }
    return false;
  }

  function oobReturn(a: Aircraft) {
    if (!params.enableOOBReturn) return;
    if (!isOutOfBounds(a.pos)) return;
    const midairActive = a.overrides.midair?.name === "ArcTurn" && (a.overrides.midair as any).source === "midair";
    if (midairActive) return; // midair keeps priority
    const wallCtrl = a.overrides.wall;
    const already = wallCtrl?.name === "ReturnToBox";
    if (already) {
      // update target
      (a.overrides.wall as any).desired = desiredInboundUnit(a);
      return;
    }
    // arm after threshold handled by tick() via oob_time
    const trig = `RTO${Math.floor(time * 1000).toString().padStart(6, "0")}`;
    a.overrides.wall = { name: "ReturnToBox", gLimit: params.OOB_RETURN_G, desired: desiredInboundUnit(a) };
    logTrigger(a.id, trig, "oob-return", `align to nearest-box-point`);
  }

  // per-aircraft open-time map for early-exit
  const openTimeRef = useRef<Record<string, number>>({});
  const oobTimeRef = useRef<Record<string, number>>({});

  function tick(dt: number) {
    const list = aircraft.map((a) => ({ ...a, pos: { ...a.pos }, vel: { ...a.vel }, overrides: { ...a.overrides } }));

    // Priority: midair before wall
    for (const a of list) {
      attemptMidair(a, list) || attemptWall(a);
    }

    // Update + OOB handling + early-exit + retrigger
    for (const a of list) {
      // OOB timers
      const wasOOB = isOutOfBounds(a.pos);
      const oobMap = oobTimeRef.current;
      if (wasOOB) oobMap[a.id] = (oobMap[a.id] || 0) + dt; else oobMap[a.id] = 0;

      // Arm OOB return when threshold met
      if (params.enableOOBReturn && wasOOB && oobMap[a.id] >= params.OOB_RETURN_AFTER) {
        oobReturn(a);
      }

      // Controller update
      updateAircraft(a, 1 / TICK_HZ); // fixed-step for stability

      // OOB release when safely inside
      if (a.overrides.wall?.name === "ReturnToBox" && isInsideMargin(a.pos, params.OOB_RELEASE_MARGIN)) {
        a.overrides.wall = undefined;
        a.motion = { name: "NormalMotion" };
        logTrigger(a.id, "OOB-RELEASE", "oob-return", `inside by ${params.OOB_RELEASE_MARGIN}m`);
      }

      // Midair early-exit (E): opening sustained
      if (params.enableGuardrail && a.overrides.midair && a.overrides.midair.name === "ArcTurn" && a.overrides.midair.source === "midair") {
        const intr = nearestIntruder(a, list);
        if (intr) {
          const r = sub(intr.pos, a.pos);
          const rHat = norm(r);
          const vRel = sub(a.vel, intr.vel);
          const rDot = dot(vRel, rHat); // >0 opening
          const key = a.id;
          if (rDot > 0) openTimeRef.current[key] = (openTimeRef.current[key] || 0) + dt; else openTimeRef.current[key] = 0;
          const sep = distance(a.pos, intr.pos);
          if (sep > params.OPEN_SAFE_SEP && (openTimeRef.current[key] || 0) >= params.OPEN_HOLD_S) {
            (a.overrides.midair as any).done = true;
            logTrigger(a.id, (a.overrides.midair as any).triggerId || "M", "midair", `early-exit open sep=${sep.toFixed(1)}`);
          }
        }
      }
    }

    // Cleanup + retrigger if still closing
    for (const a of list) {
      for (const key of ["midair", "wall"] as const) {
        const c = a.overrides[key];
        if (c && c.name === "ArcTurn" && (c as any).done) {
          a.overrides[key] = undefined;
          a.motion = { name: "NormalMotion" };
          if (key === "midair") {
            const intr = nearestIntruder(a, list);
            if (intr) {
              const r = sub(intr.pos, a.pos);
              const rHat = norm(r);
              const vRel = sub(a.vel, intr.vel);
              if (dot(vRel, rHat) < 0 && distance(a.pos, intr.pos) < params.OPEN_SAFE_SEP) {
                attemptMidair(a, list);
              }
            }
          }
        }
      }
    }

    // Collision: fatal (stop aircraft by zero speed)
    const collisions: [string, string, number][] = [];
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const d = distance(list[i].pos, list[j].pos);
        if (d < 20) collisions.push([list[i].id, list[j].id, d]);
      }
    }
    if (collisions.length) {
      for (const [a, b, d] of collisions) {
        logTrigger(a, "C", "collision", `with ${b} @ ${d.toFixed(1)}m`);
      }
      // Stop sim on first fatal collision (optional). Comment out to keep going.
      // setRunning(false);
    }

    // Commit
    setAircraft(list);

    // Time
    setTime((t) => t + 1 / TICK_HZ);

    // Charting data (keep last ~120s)
    const row: any = { t: Number((time + 1 / TICK_HZ).toFixed(2)) };
    for (const [a, b] of pairs) {
      const A = list.find((x) => x.id === a)!;
      const B = list.find((x) => x.id === b)!;
      row[`${a}-${b}`] = Number(distance(A.pos, B.pos).toFixed(1));
    }
    setHistory((H) => {
      const next = [...H, row];
      const MAX = 120 * TICK_HZ;
      return next.slice(-MAX);
    });
  }

  function resetSim(n?: number) {
    globalIdCounter = 0;
    const N = clamp(n ?? aircraft.length, 2, MAX_AIRCRAFT);
    setAircraft(Array.from({ length: N }, (_, i) => newAircraft(i)));
    setLogs([]);
    setHistory([]);
    setTime(0);
    lastTs.current = null;
  }

  return (
    <div className="min-h-screen bg-[#0b0e14] text-white">
      <header className="sticky top-0 z-10 border-b border-white/10 bg-black/30 backdrop-blur p-3">
        <div className="mx-auto max-w-7xl flex items-center gap-3">
          <Radar className="w-6 h-6 text-indigo-300" />
          <h1 className="text-lg font-semibold tracking-wide">Airpark — Live UAV Collision Avoidance Lab</h1>
          <div className="ml-auto flex items-center gap-2">
            <button onClick={() => setRunning((r) => !r)} className="px-3 py-1.5 rounded-xl bg-indigo-600/80 hover:bg-indigo-600 flex items-center gap-2 text-sm">
              {running ? (<><Pause className="w-4 h-4"/> Pause</>) : (<><Play className="w-4 h-4"/> Run</>)}
            </button>
            <button onClick={() => resetSim()} className="px-3 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-600 flex items-center gap-2 text-sm"><RotateCcw className="w-4 h-4"/> Reset</button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl p-3 grid grid-cols-1 xl:grid-cols-2 gap-3">
        {/* RIGHT: Arena (dominant). First in DOM for mobile, second column on xl */}
        <section className="order-1 xl:order-2 xl:sticky xl:top-[56px] self-start">
          <div className="rounded-2xl bg-[#0f1420] p-3 shadow ring-1 ring-white/10">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2"><Zap className="w-4 h-4 text-amber-300"/><span className="font-medium">Arena</span></div>
              <div className="text-xs text-white/60">t={time.toFixed(1)}s · n={aircraft.length}</div>
            </div>
            <div className="h-[60vh] md:h-[70vh] xl:h-[calc(100vh-120px)]">
              <canvas ref={canvasRef} className="w-full h-full rounded-xl border border-white/10 bg-gradient-to-b from-[#0b0e14] to-[#0c1220]" />
            </div>
          </div>
        </section>

        {/* LEFT: Chart on top; below that Logs + Controls split */}
        <section className="order-2 xl:order-1 grid grid-rows-[auto_minmax(0,1fr)] gap-3 min-h-[calc(100vh-120px)]">
          {/* Top: Pairwise separation chart */}
          <div className="rounded-2xl bg-[#0f1420] p-3 shadow ring-1 ring-white/10">
            <div className="flex items-center gap-2 mb-2"><Radar className="w-4 h-4 text-green-300"/><span className="font-medium">Pairwise Separation (live)</span></div>
            <div className="h-[32vh] md:h-[38vh] xl:h-[40vh]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={history.slice(-600)} margin={{ left: 10, right: 10, top: 10, bottom: 10 }}>
                  <XAxis dataKey="t" tick={{ fill: "#9ba3af" }} tickFormatter={(v)=>v.toFixed?.(0) ?? v} />
                  <YAxis tick={{ fill: "#9ba3af" }} domain={[0, (dataMax)=> Math.max(100, Math.ceil((dataMax||0)*1.1))]} />
                  <Tooltip contentStyle={{ background: "#0b0e14", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, color: "white" }} />
                  <Legend wrapperStyle={{ color: "#cbd5e1" }} />
                  {pairs.map(([a,b])=> (
                    <Line key={`${a}-${b}`} type="monotone" dataKey={`${a}-${b}`} dot={false} strokeWidth={1.8} isAnimationActive={false} />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Bottom: Logs + Controls share the space */}
          <div className="grid grid-rows-2 md:grid-rows-1 md:grid-cols-2 gap-3 min-h-0">
            {/* Logs */}
            <div className="rounded-2xl bg-[#0f1420] p-3 shadow ring-1 ring-white/10 min-h-0">
              <div className="flex items-center gap-2 mb-2"><Zap className="w-4 h-4 text-amber-300"/><span className="font-medium">Control Callouts</span></div>
              <div className="h-full max-h-[38vh] md:max-h-none md:h-[calc(100vh-420px)] overflow-auto space-y-1 pr-1">
                {logs.slice(0,150).map((r,idx)=> (
                  <div key={idx} className="text-xs text-white/80 grid grid-cols-[72px_52px_1fr] gap-2">
                    <span className="text-white/60">{r.t.toFixed(2)}s</span>
                    <span className="font-semibold">{r.aid}</span>
                    <span className="truncate">[{r.source}] {r.note}</span>
                  </div>
                ))}
                {logs.length===0 && <div className="text-xs text-white/50">(No events yet)</div>}
              </div>
            </div>

            {/* Controls */}
            <div className="rounded-2xl bg-[#0f1420] p-3 shadow ring-1 ring-white/10 min-h-0 overflow-auto">
              <div className="flex items-center gap-2 mb-2"><Settings2 className="w-4 h-4 text-cyan-300"/><span className="font-medium">Parameters</span></div>

              <ParamGroup title="Midair (A, B, D, E)">
                <Toggle label="Enable Midair" value={params.enableMidair} onChange={(v)=>setParams(p=>({...p, enableMidair:v}))} />
                <Slider label="MID_TTC_THRESHOLD" min={0.5} max={8} step={0.1} value={params.MID_TTC_THRESHOLD} onChange={(v)=>setParams(p=>({...p, MID_TTC_THRESHOLD:v}))} />
                <Slider label="MID_SEP_TRIGGER" min={20} max={200} step={5} value={params.MID_SEP_TRIGGER} onChange={(v)=>setParams(p=>({...p, MID_SEP_TRIGGER:v}))} />
                <Slider label="K_GAIN (g scaling)" min={0.05} max={0.6} step={0.01} value={params.K_GAIN} onChange={(v)=>setParams(p=>({...p, K_GAIN:v}))} />
                <TwoSlider labelA="G_MIN" labelB="G_MAX" min={1.5} max={6} step={0.1} valueA={params.G_MIN} valueB={params.G_MAX} onChangeA={(v)=>setParams(p=>({...p, G_MIN:v}))} onChangeB={(v)=>setParams(p=>({...p, G_MAX:v}))} />
                <Slider label="Shadow HORIZON_S" min={1} max={6} step={0.1} value={params.HORIZON_S} onChange={(v)=>setParams(p=>({...p, HORIZON_S:v}))} />
              </ParamGroup>

              <ParamGroup title="Wall & OOB">
                <Toggle label="Enable Wall Avoidance" value={params.enableWall} onChange={(v)=>setParams(p=>({...p, enableWall:v}))} />
                <Slider label="WALL_TTC_THRESHOLD" min={1} max={6} step={0.1} value={params.WALL_TTC_THRESHOLD} onChange={(v)=>setParams(p=>({...p, WALL_TTC_THRESHOLD:v}))} />
                <Slider label="WALL_PADDING" min={0} max={80} step={2} value={params.WALL_PADDING} onChange={(v)=>setParams(p=>({...p, WALL_PADDING:v}))} />
                <Toggle label="Enable OOB Return" value={params.enableOOBReturn} onChange={(v)=>setParams(p=>({...p, enableOOBReturn:v}))} />
                <Slider label="OOB_RETURN_AFTER" min={0.2} max={5} step={0.1} value={params.OOB_RETURN_AFTER} onChange={(v)=>setParams(p=>({...p, OOB_RETURN_AFTER:v}))} />
                <Slider label="OOB_RETURN_G" min={1.5} max={6} step={0.1} value={params.OOB_RETURN_G} onChange={(v)=>setParams(p=>({...p, OOB_RETURN_G:v}))} />
                <Slider label="OOB_RELEASE_MARGIN" min={0} max={20} step={0.5} value={params.OOB_RELEASE_MARGIN} onChange={(v)=>setParams(p=>({...p, OOB_RELEASE_MARGIN:v}))} />
              </ParamGroup>

              <ParamGroup title="Early Exit (E) & Retrigger (F)">
                <Toggle label="Enable Early-Exit + Retrigger" value={params.enableGuardrail} onChange={(v)=>setParams(p=>({...p, enableGuardrail:v}))} />
                <Slider label="OPEN_SAFE_SEP" min={40} max={200} step={5} value={params.OPEN_SAFE_SEP} onChange={(v)=>setParams(p=>({...p, OPEN_SAFE_SEP:v}))} />
                <Slider label="OPEN_HOLD_S" min={0.1} max={2} step={0.05} value={params.OPEN_HOLD_S} onChange={(v)=>setParams(p=>({...p, OPEN_HOLD_S:v}))} />
              </ParamGroup>

             <div className="mt-3 space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={fastScoreNow}
                  disabled={scoring}
                  className={`px-3 py-1.5 rounded-xl text-sm ${scoring ? "bg-emerald-700/60 cursor-wait" : "bg-emerald-600 hover:bg-emerald-500"}`}
                  title="Monte-Carlo fast score of current parameters"
                >
                  {scoring ? "Scoring…" : "Fast score (64×2min)"}
                </button>

                <button onClick={()=>resetSim()} className="px-3 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-600 flex items-center gap-2 text-sm">
                  <RefreshCw className="w-4 h-4"/> Re-randomize
                </button>
                <button onClick={()=>resetSim(aircraft.length+1)} className="px-3 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-sm">+ Plane</button>
                <button onClick={()=>resetSim(Math.max(2, aircraft.length-1))} className="px-3 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-sm">− Plane</button>
              </div>

              {fastScore && (
                <div className="grid grid-cols-2 gap-2 text-xs text-white/80 rounded-xl border border-white/10 p-2">
                  <div>λ (collisions/hr): <span className="font-semibold">{fastScore.lambda_per_hour.toFixed(3)}</span></div>
                  <div>10-yr risk: <span className="font-semibold">{(fastScore.ten_year_risk*100).toFixed(2)}%</span></div>
                  <div>collisions: <span className="font-semibold">{fastScore.collisions}</span></div>
                  <div>near-misses (&lt;30m): <span className="font-semibold">{fastScore.near_misses}</span></div>
                  <div>avg sep: <span className="font-semibold">{fastScore.avg_sep.toFixed(1)} m</span></div>
                  <div>system duty: <span className="font-semibold">{(fastScore.system_frac*100).toFixed(1)}%</span></div>
                </div>
              )}
            </div>

            </div>
          </div>
        </section>
      </main>

      <footer className="mx-auto max-w-7xl p-6 text-xs text-white/50">
        The challenge: build an Airpark where many planes fly in a confined space. Any collision is fatal. Tweak parameters and avoidance combinations to explore emergent flight patterns.
      </footer>
    </div>
  );
}

/*********************************
 * UI bits
 *********************************/
function ParamGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-3 rounded-xl border border-white/10 p-3">
      <div className="text-xs uppercase tracking-wider text-white/60 mb-2">{title}</div>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean)=>void }) {
  return (
    <label className="flex items-center justify-between gap-3 text-sm">
      <span className="text-white/80">{label}</span>
      <button onClick={()=>onChange(!value)} className={`h-6 w-10 rounded-full transition ${value?"bg-emerald-500":"bg-slate-600"}`}>
        <span className={`block h-6 w-6 rounded-full bg-white transform transition ${value?"translate-x-4":"translate-x-0"}`}></span>
      </button>
    </label>
  );
}

function Slider({ label, min, max, step, value, onChange }: { label: string; min: number; max: number; step: number; value: number; onChange: (v:number)=>void }) {
  return (
    <div className="grid grid-cols-[1fr_auto] items-center gap-3 text-sm">
      <div>
        <div className="text-white/80">{label}</div>
        <input type="range" className="w-full" min={min} max={max} step={step} value={value} onChange={(e)=>onChange(Number(e.target.value))} />
      </div>
      <div className="text-white/70 tabular-nums min-w-[64px] text-right">{value.toFixed(2)}</div>
    </div>
  );
}

function TwoSlider({ labelA, labelB, min, max, step, valueA, valueB, onChangeA, onChangeB }:{ labelA: string; labelB: string; min:number; max:number; step:number; valueA:number; valueB:number; onChangeA:(v:number)=>void; onChangeB:(v:number)=>void }){
  return (
    <div className="space-y-2">
      <Slider label={labelA} min={min} max={max} step={step} value={valueA} onChange={onChangeA} />
      <Slider label={labelB} min={min} max={max} step={step} value={valueB} onChange={onChangeB} />
    </div>
  );
}
